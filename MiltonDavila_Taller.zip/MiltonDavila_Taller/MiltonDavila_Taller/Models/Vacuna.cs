﻿namespace MiltonDavila_Taller.Models
{
    public class Vacuna
        
    {
        public int Id { get; set; }
        public required string NombreVacuna { get; set; }

        public required string paisProcedencia { get; set; }


    }
}
